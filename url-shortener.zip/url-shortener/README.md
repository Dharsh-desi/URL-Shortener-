# ⚡ SnapLink — URL Shortener

A clean, fast, frontend-only URL shortener built with pure HTML, CSS, and JavaScript. No backend. No signup. Just paste and shorten.

![SnapLink Screenshot](screenshot.png)

---

## 🚀 Live Demo

👉 [View on GitHub Pages](https://yourusername.github.io/url-shortener)

---

## ✨ Features

- **Instant shortening** — generates a unique 6-character short code
- **Copy to clipboard** — one click to copy your short URL
- **History tracking** — all your links saved in localStorage (persists on refresh)
- **Delete individual links** or clear all history
- **Stats counter** — tracks total links shortened and copies
- **Duplicate detection** — won't create a new short link if you paste the same URL twice
- **Input validation** — handles missing `https://` automatically
- **Responsive** — works on mobile, tablet, and desktop
- **Dark mode design** — easy on the eyes

---

## 🛠️ Tech Stack

| Technology | Purpose |
|---|---|
| HTML5 | Page structure & semantics |
| CSS3 | Styling, animations, responsive layout |
| Vanilla JavaScript | URL logic, DOM manipulation |
| localStorage | Persistent history (no backend needed) |
| Google Fonts | Space Grotesk + Inter typefaces |

---

## 📁 Project Structure

```
url-shortener/
│
├── index.html          # Main HTML page
├── css/
│   └── style.css       # All styles + responsive design
├── js/
│   └── app.js          # Core logic (shorten, copy, history)
└── README.md           # This file
```

---

## ⚙️ How It Works

1. User pastes a long URL into the input field
2. JavaScript validates the URL (auto-adds `https://` if missing)
3. A unique 6-character alphanumeric code is generated
4. The short URL is displayed and saved to `localStorage`
5. User can copy the short link with one click
6. All history persists across browser sessions

> **Note:** Since this is a frontend-only project, the short URLs are simulated (they use the domain `snaplnk.io` as a placeholder). In a real production app, you'd connect this to a backend + database to actually resolve short URLs.

---

## 🔧 How to Run Locally

```bash
# 1. Clone the repo
git clone https://github.com/yourusername/url-shortener.git

# 2. Open the folder
cd url-shortener

# 3. Open index.html in your browser
# (Double-click index.html, or use Live Server in VS Code)
```

No installations. No npm. No build step. Just open and use.

---

## 🚀 Deploy to GitHub Pages

1. Push the project to a GitHub repo
2. Go to **Settings → Pages**
3. Under **Source**, select `main` branch and `/ (root)` folder
4. Click Save — your live URL will appear in ~1 minute

---

## 💡 Future Improvements

- [ ] Connect to a real backend (Node.js / Flask) for actual URL redirection
- [ ] QR code generation for each short link
- [ ] Click analytics (track how many times a link was opened)
- [ ] Custom alias support (e.g. `snaplnk.io/my-portfolio`)
- [ ] Expiry dates for links
- [ ] Light mode toggle

---

## 👩‍💻 Built By

**Dharshini** — Data Analytics & Web Dev Portfolio Project  
[LinkedIn](https://linkedin.com/in/dharshini) · [GitHub](https://github.com/yourusername)

---

## 📄 License

MIT License — free to use, modify, and share.
