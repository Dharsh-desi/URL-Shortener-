// ==============================
//   SnapLink — URL Shortener
//   Pure HTML/CSS/JS + localStorage
// ==============================

const BASE_URL = "https://snaplnk.io/";
let totalCopies = parseInt(localStorage.getItem("sl_copies") || "0");

// ---- DOM READY ----
document.addEventListener("DOMContentLoaded", () => {
  renderHistory();
  updateStats();

  // Allow Enter key to shorten
  document.getElementById("longUrlInput").addEventListener("keydown", (e) => {
    if (e.key === "Enter") shortenUrl();
  });
});

// ==============================
//   CORE: SHORTEN URL
// ==============================
function shortenUrl() {
  const input = document.getElementById("longUrlInput");
  const hint = document.getElementById("inputHint");
  const raw = input.value.trim();

  // Validate
  if (!raw) {
    hint.textContent = "Please paste a URL first.";
    return;
  }

  const url = ensureProtocol(raw);

  if (!isValidUrl(url)) {
    hint.textContent = "That doesn't look like a valid URL. Try including https://";
    return;
  }

  hint.textContent = "";

  // Check if already shortened
  const existing = getHistory().find((item) => item.original === url);
  if (existing) {
    showResult(existing.short, url);
    showToast("⚡ Already shortened — here it is again!");
    return;
  }

  // Generate short code
  const code = generateCode();
  const shortUrl = BASE_URL + code;

  // Save to history
  const entry = {
    id: Date.now(),
    original: url,
    short: shortUrl,
    code: code,
    createdAt: new Date().toISOString(),
  };

  saveToHistory(entry);
  showResult(shortUrl, url);
  renderHistory();
  updateStats();
  showToast("✅ Link shortened!");
}

// ==============================
//   GENERATE SHORT CODE
// ==============================
function generateCode() {
  const chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
  let code = "";
  for (let i = 0; i < 6; i++) {
    code += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  // Ensure uniqueness
  const history = getHistory();
  const exists = history.some((item) => item.code === code);
  return exists ? generateCode() : code;
}

// ==============================
//   SHOW RESULT BOX
// ==============================
function showResult(shortUrl, originalUrl) {
  const resultBox = document.getElementById("resultBox");
  const shortDisplay = document.getElementById("shortUrlDisplay");
  const originalDisplay = document.getElementById("originalUrlDisplay");

  shortDisplay.textContent = shortUrl;
  originalDisplay.textContent = originalUrl;
  resultBox.style.display = "block";
  resultBox.scrollIntoView({ behavior: "smooth", block: "nearest" });

  // Reset copy button
  document.getElementById("copyBtn").textContent = "Copy";
}

// ==============================
//   COPY SHORT URL
// ==============================
function copyUrl() {
  const shortUrl = document.getElementById("shortUrlDisplay").textContent;
  navigator.clipboard.writeText(shortUrl).then(() => {
    const btn = document.getElementById("copyBtn");
    btn.textContent = "Copied!";
    setTimeout(() => (btn.textContent = "Copy"), 2000);

    // Increment copy count
    totalCopies++;
    localStorage.setItem("sl_copies", totalCopies);
    updateStats();
    showToast("📋 Copied to clipboard!");
  });
}

// ==============================
//   OPEN SHORT URL
// ==============================
function openUrl() {
  const shortUrl = document.getElementById("shortUrlDisplay").textContent;
  // Since this is a demo, open the original URL
  const history = getHistory();
  const entry = history.find((item) => item.short === shortUrl);
  if (entry) {
    window.open(entry.original, "_blank");
  }
}

// ==============================
//   HISTORY: SAVE / GET / CLEAR
// ==============================
function saveToHistory(entry) {
  const history = getHistory();
  history.unshift(entry); // newest first
  localStorage.setItem("sl_history", JSON.stringify(history));
}

function getHistory() {
  return JSON.parse(localStorage.getItem("sl_history") || "[]");
}

function clearHistory() {
  if (confirm("Clear all shortened links? This cannot be undone.")) {
    localStorage.removeItem("sl_history");
    renderHistory();
    updateStats();
    showToast("🗑️ History cleared");
  }
}

function deleteEntry(id) {
  const history = getHistory().filter((item) => item.id !== id);
  localStorage.setItem("sl_history", JSON.stringify(history));
  renderHistory();
  updateStats();
  showToast("Deleted");
}

// ==============================
//   RENDER HISTORY LIST
// ==============================
function renderHistory() {
  const list = document.getElementById("historyList");
  const empty = document.getElementById("emptyState");
  const history = getHistory();

  // Remove existing items (keep empty state)
  const items = list.querySelectorAll(".history-item");
  items.forEach((el) => el.remove());

  if (history.length === 0) {
    empty.style.display = "block";
    return;
  }

  empty.style.display = "none";

  history.forEach((entry) => {
    const div = document.createElement("div");
    div.className = "history-item";
    div.innerHTML = `
      <div class="history-urls">
        <span class="history-short">${entry.short}</span>
        <span class="history-original">${entry.original}</span>
        <span class="history-time">${formatDate(entry.createdAt)}</span>
      </div>
      <div class="history-actions">
        <button class="h-copy-btn" onclick="copyHistoryItem('${entry.short}')">Copy</button>
        <button class="h-delete-btn" onclick="deleteEntry(${entry.id})">✕</button>
      </div>
    `;
    list.appendChild(div);
  });
}

// ==============================
//   COPY FROM HISTORY
// ==============================
function copyHistoryItem(shortUrl) {
  navigator.clipboard.writeText(shortUrl).then(() => {
    totalCopies++;
    localStorage.setItem("sl_copies", totalCopies);
    updateStats();
    showToast("📋 Copied!");
  });
}

// ==============================
//   STATS
// ==============================
function updateStats() {
  const history = getHistory();
  document.getElementById("totalLinks").textContent = history.length;
  document.getElementById("totalCopies").textContent = totalCopies;
}

// ==============================
//   HELPERS
// ==============================
function isValidUrl(str) {
  try {
    const url = new URL(str);
    return url.protocol === "http:" || url.protocol === "https:";
  } catch {
    return false;
  }
}

function ensureProtocol(url) {
  if (!/^https?:\/\//i.test(url)) {
    return "https://" + url;
  }
  return url;
}

function formatDate(isoString) {
  const date = new Date(isoString);
  return date.toLocaleDateString("en-IN", {
    day: "numeric",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

// ==============================
//   TOAST NOTIFICATION
// ==============================
function showToast(message) {
  const existing = document.querySelector(".toast");
  if (existing) existing.remove();

  const toast = document.createElement("div");
  toast.className = "toast";
  toast.textContent = message;
  document.body.appendChild(toast);

  setTimeout(() => toast.remove(), 2200);
}
